<?php return array (
  0 => 'App\\Domain\\User\\Entity\\User',
  1 => 'App\\Entity\\Order',
  2 => 'App\\Entity\\Product',
  3 => 'App\\Entity\\Store',
);