<?php return array (
  0 => 'App\\Endpoint\\Web\\Api',
  1 => 'App\\Endpoint\\Web\\HomeController',
);