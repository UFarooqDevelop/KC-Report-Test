<?php

declare(strict_types=1);

namespace App\Endpoint\Web;

use App\Entity\Order;
use Cycle\ORM\ORMInterface;
use Spiral\Http\ResponseWrapper;
use Spiral\Router\Annotation\Route;
use Cycle\Database\Injection\Fragment;
use Cycle\Database\DatabaseProviderInterface;

final class Api
{
    private ResponseWrapper $response;
    private DatabaseProviderInterface $db;

    
    public function __construct(ResponseWrapper $response, DatabaseProviderInterface $db)
    {
        $this->response = $response;
        $this->db = $db;

    }
    
    #[Route(route: '/show-orders', name: 'show-orders', methods: 'GET')]
    public function showOrders(ORMInterface $orm): \Psr\Http\Message\ResponseInterface
    {
        $repository = $orm->getRepository(Order::class);
        
        $orders = $repository->findAll();
        $data = array_map(fn(Order $order) => $order->toArray(), $orders);
        
        return $this->response->json(['data' => $data]);
    }

    // New route for monthly sales by region
            #[Route(route: '/monthly-sales-by-region', name: 'monthly-sales-by-region', methods: 'GET')]
            public function showReportMonthlySalesByRegion(ORMInterface $orm): \Psr\Http\Message\ResponseInterface
            {
             $repository = $orm->getRepository(Order::class); 
                // Define the date range (last 12 months)
                    $endDate = new \DateTimeImmutable();
                    $startDate = $endDate->modify('-12 months');

                    // $database = $this->db->database();
                    // $query = $database->select(
                    //     new Fragment('SUM(quantity * unit_price) AS total_sales_amount'),
                    //     new Fragment('COUNT(order_id) AS number_of_orders')
                    // )
                    //     ->from('orders')
                    //     ->join('INNER JOIN', 'stores', 's', ['orders.store_id' => 's.store_id'])
                    //     ->where(new Fragment('order_date BETWEEN ? AND ?', [
                    //         $startDate->format('Y-m-d'),
                    //         $endDate->format('Y-m-d'),
                    //     ]))
                    //     ->groupBy(new Fragment('YEAR(order_date)'))
                    //     ->groupBy(new Fragment('MONTH(order_date)'))
                    //     ->groupBy(new Fragment('s.region_id'))
                    //     ->fetchAll();
                    $query = $repository->select([
                        'store.*',
                        'YEAR(order_date) AS year', // Group by year
                    ])
                    ->with('store') // Load the related Store entity
                    ->where('order_date', '>=', $startDate->format('Y-m-d')) // Filter start date
                    ->andWhere('order_date', '<=', $endDate->format('Y-m-d')) // Filter end date
                    ->groupBy('store.region_id') // Group by year
                    ->fetchALL();


             

                     return $this->response->json(['data' => $query]);

            }
}