<?php

declare(strict_types=1);

namespace App;

use Cycle\Migrations\Migration;

class DefaultProductsMigration extends Migration
{
    /**
     * Create tables, add columns or insert data here
     */
    public function up(): void
    {
        $this->table('products')
        ->addColumn('product_id', 'bigPrimary', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('category_id', 'bigInteger', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('product_name', 'string', ['nullable' => false, 'defaultValue' => null, 'length' => 200, 'size' => 255])
        ->setPrimaryKeys(['product_id'])
        ->create();
    }

    /**
     * Drop created, columns and etc here
     */
    public function down(): void
    {
        $this->table('products')->drop();

    }
}
