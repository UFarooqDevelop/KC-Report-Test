<?php

declare(strict_types=1);

namespace App;

use Cycle\Migrations\Migration;

class DefaultStoresMigration extends Migration
{
    /**
     * Create tables, add columns or insert data here
     */
    public function up(): void
    {
        $this->table('stores')
        ->addColumn('store_id', 'bigPrimary', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('region_id', 'bigInteger', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('store_name', 'string', ['nullable' => false, 'defaultValue' => null, 'length' => 200, 'size' => 255])
        ->setPrimaryKeys(['store_id'])
        ->create();
    }

    /**
     * Drop created, columns and etc here
     */
    public function down(): void
    {
        $this->table('stores')->drop();

    }
}
