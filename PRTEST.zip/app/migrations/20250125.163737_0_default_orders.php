<?php

declare(strict_types=1);

namespace App;

use Cycle\Migrations\Migration;

class DefaultOrdersMigration extends Migration
{
    /**
     * Create tables, add columns or insert data here
     */
    public function up(): void
    {
        $this->table('orders')
        ->addColumn('order_id', 'bigPrimary', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('customer_id', 'bigInteger', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('product_id', 'bigInteger', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('quantity', 'integer', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('unit_price', 'decimal', ['nullable' => false, 'defaultValue' => null, 'precision' => 10, 'scale' => 2])
        ->addColumn('order_date', 'date', ['nullable' => false, 'defaultValue' => null])
        ->addColumn('store_id', 'bigInteger', ['nullable' => false, 'defaultValue' => null])
        ->addIndex(['store_id'], ['name' => 'orders_index_store_id_6790d290a19b9', 'unique' => false])
        ->addIndex(['product_id'], ['name' => 'orders_index_product_id_6790d290a1b17', 'unique' => false])
        ->addForeignKey(['store_id'], 'stores', ['store_id'], [
            'name' => 'orders_store_id_fk',
            'delete' => 'CASCADE',
            'update' => 'CASCADE',
            'indexCreate' => true,
        ])
        ->addForeignKey(['product_id'], 'products', ['product_id'], [
            'name' => 'orders_product_id_fk',
            'delete' => 'CASCADE',
            'update' => 'CASCADE',
            'indexCreate' => true,
        ])
        ->setPrimaryKeys(['order_id'])
        ->create();
    }

    /**
     * Drop created, columns and etc here
     */
    public function down(): void
    {
        $this->table('orders')->drop();

    }
}
